AF_INET = 2
AF_INET6 = 10
SOCK_DGRAM = 2
SOCK_RAW = 3
SOCK_STREAM = 1


def getaddrinfo():
    pass


class socket:
    ""

    def accept():
        pass

    def bind():
        pass

    def close():
        pass

    def connect():
        pass

    def listen():
        pass

    def recv():
        pass

    def recvfrom():
        pass

    def send():
        pass

    def sendto():
        pass

    def setblocking():
        pass

    def setsockopt():
        pass

    def settimeout():
        pass
