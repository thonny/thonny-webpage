def namedtuple():
    pass
