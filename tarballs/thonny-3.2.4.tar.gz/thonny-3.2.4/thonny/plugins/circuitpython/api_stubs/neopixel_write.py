def neopixel_write():
    pass
