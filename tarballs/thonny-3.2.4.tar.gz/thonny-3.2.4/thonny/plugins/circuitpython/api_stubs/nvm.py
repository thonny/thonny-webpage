class ByteArray:
    ""
