A0 = None
A1 = None
A2 = None
A3 = None
A4 = None
A5 = None
A6 = None
A7 = None
A8 = None
A9 = None
ACCELEROMETER_INTERRUPT = None
ACCELEROMETER_SCL = None
ACCELEROMETER_SDA = None
BUTTON_A = None
BUTTON_B = None
D0 = None
D1 = None
D10 = None
D12 = None
D13 = None
D2 = None
D3 = None
D4 = None
D5 = None
D6 = None
D7 = None
D8 = None
D9 = None


def I2C():
    pass


IR_PROXIMITY = None
IR_RX = None
IR_TX = None
LIGHT = None
MICROPHONE_CLOCK = None
MICROPHONE_DATA = None
MISO = None
MOSI = None
NEOPIXEL = None
REMOTEIN = None
REMOTEOUT = None
RX = None
SCK = None
SCL = None
SDA = None
SLIDE_SWITCH = None
SPEAKER = None
SPEAKER_ENABLE = None


def SPI():
    pass


TEMPERATURE = None
TX = None


def UART():
    pass
