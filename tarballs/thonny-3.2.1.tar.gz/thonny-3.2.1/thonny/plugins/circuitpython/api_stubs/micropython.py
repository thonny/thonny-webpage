def const():
    pass


def heap_lock():
    pass


def heap_unlock():
    pass


def kbd_intr():
    pass


def opt_level():
    pass
