argv = None
byteorder = "little"


def exit():
    pass


implementation = None
maxsize = 2147483647
modules = None
path = None
platform = "Atmel SAMD21"


def print_exception():
    pass


stderr = None
stdin = None
stdout = None
version = "3.4.0"
version_info = None
