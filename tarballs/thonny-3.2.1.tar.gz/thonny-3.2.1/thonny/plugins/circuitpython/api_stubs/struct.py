def calcsize():
    pass


def pack():
    pass


def pack_into():
    pass


def unpack():
    pass


def unpack_from():
    pass
