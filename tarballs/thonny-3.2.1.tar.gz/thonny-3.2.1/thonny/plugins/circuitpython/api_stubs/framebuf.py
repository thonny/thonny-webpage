class FrameBuffer:
    ""

    def blit():
        pass

    def fill():
        pass

    def fill_rect():
        pass

    def hline():
        pass

    def line():
        pass

    def pixel():
        pass

    def rect():
        pass

    def scroll():
        pass

    def text():
        pass

    def vline():
        pass


def FrameBuffer1():
    pass


GS4_HMSB = 2
MONO_HLSB = 3
MONO_HMSB = 4
MONO_VLSB = 0
MVLSB = 0
RGB565 = 1
