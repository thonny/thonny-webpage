class PWMOut:
    ""


class PulseIn:
    ""

    def clear():
        pass

    def deinit():
        pass

    maxlen = None

    def pause():
        pass

    paused = None

    def popleft():
        pass

    def resume():
        pass


class PulseOut:
    ""

    def deinit():
        pass

    def send():
        pass
