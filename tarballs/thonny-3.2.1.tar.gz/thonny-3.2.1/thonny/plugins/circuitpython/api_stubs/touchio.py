class TouchIn:
    ""

    def deinit():
        pass

    raw_value = None
    threshold = None
    value = None
