GRB = None
GRBW = None


class NeoPixel:
    ""

    def _set_item():
        pass

    brightness = None

    def deinit():
        pass

    def fill():
        pass

    def show():
        pass

    def write():
        pass


RGB = None
RGBW = None
digitalio = None
math = None


def neopixel_write():
    pass
