byteorder = "little"


def exit():
    pass


implementation = None
platform = "microbit"


def print_exception():
    pass


version = "3.4.0"
version_info = None
