def pronounce():
    pass


def say():
    pass


def sing():
    pass


def translate():
    pass
