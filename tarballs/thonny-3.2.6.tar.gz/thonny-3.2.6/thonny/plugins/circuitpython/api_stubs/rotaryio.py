class IncrementalEncoder:
    ""

    def deinit():
        pass

    position = None
