class GamePad:
    ""

    def deinit():
        pass

    def get_pressed():
        pass
