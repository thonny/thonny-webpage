class RTC:
    ""
    calibration = None
    datetime = None


def set_time_source():
    pass
