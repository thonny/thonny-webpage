class Image:
    ""


accelerometer = None
button_a = None
button_b = None
compass = None
display = None
i2c = None


def panic():
    pass


pin0 = None
pin1 = None
pin10 = None
pin11 = None
pin12 = None
pin13 = None
pin14 = None
pin15 = None
pin16 = None
pin19 = None
pin2 = None
pin20 = None
pin3 = None
pin4 = None
pin5 = None
pin6 = None
pin7 = None
pin8 = None
pin9 = None


def reset():
    pass


def running_time():
    pass


def sleep():
    pass


spi = None


def temperature():
    pass


uart = None
