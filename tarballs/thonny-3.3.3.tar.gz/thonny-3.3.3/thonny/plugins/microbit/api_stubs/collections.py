class OrderedDict:
    ""

    def clear():
        pass

    def copy():
        pass

    def fromkeys():
        pass

    def get():
        pass

    def items():
        pass

    def keys():
        pass

    def pop():
        pass

    def popitem():
        pass

    def setdefault():
        pass

    def update():
        pass

    def values():
        pass


def namedtuple():
    pass
