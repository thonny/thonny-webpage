def disable_irq():
    pass


def enable_irq():
    pass


def freq():
    pass


mem16 = None
mem32 = None
mem8 = None


def reset():
    pass


def time_pulse_us():
    pass


def unique_id():
    pass
