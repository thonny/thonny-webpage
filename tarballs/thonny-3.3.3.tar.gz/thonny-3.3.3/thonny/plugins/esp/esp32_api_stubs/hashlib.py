class sha1:
    ""

    def digest():
        pass

    def update():
        pass


class sha256:
    ""

    def digest():
        pass

    def update():
        pass
