class websocket:
    ""

    def close():
        pass

    def ioctl():
        pass

    def read():
        pass

    def readinto():
        pass

    def readline():
        pass

    def write():
        pass
