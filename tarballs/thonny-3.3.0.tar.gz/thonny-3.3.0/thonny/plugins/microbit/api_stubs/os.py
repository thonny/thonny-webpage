def listdir():
    pass


def remove():
    pass


def size():
    pass


def uname():
    pass
