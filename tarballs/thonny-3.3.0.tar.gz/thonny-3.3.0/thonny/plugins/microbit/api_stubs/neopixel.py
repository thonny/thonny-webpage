class NeoPixel:
    ""

    def clear():
        pass

    def show():
        pass
