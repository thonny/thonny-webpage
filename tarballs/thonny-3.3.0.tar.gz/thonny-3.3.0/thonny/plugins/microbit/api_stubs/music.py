BADDY = None
BA_DING = None
BIRTHDAY = None
BLUES = None
CHASE = None
DADADADUM = None
ENTERTAINER = None
FUNERAL = None
FUNK = None
JUMP_DOWN = None
JUMP_UP = None
NYAN = None
ODE = None
POWER_DOWN = None
POWER_UP = None
PRELUDE = None
PUNCHLINE = None
PYTHON = None
RINGTONE = None
WAWAWAWAA = None
WEDDING = None


def get_tempo():
    pass


def pitch():
    pass


def play():
    pass


def reset():
    pass


def set_tempo():
    pass


def stop():
    pass
