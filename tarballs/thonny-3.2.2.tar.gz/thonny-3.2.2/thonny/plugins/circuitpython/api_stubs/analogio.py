class AnalogIn:
    ""

    def deinit():
        pass

    reference_voltage = None
    value = None


class AnalogOut:
    ""

    def deinit():
        pass

    value = None
