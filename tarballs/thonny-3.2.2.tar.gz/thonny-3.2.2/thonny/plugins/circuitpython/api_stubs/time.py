def localtime():
    pass


def mktime():
    pass


def monotonic():
    pass


def monotonic_ns():
    pass


def sleep():
    pass


class struct_time:
    ""

    def count():
        pass

    def index():
        pass


def time():
    pass
