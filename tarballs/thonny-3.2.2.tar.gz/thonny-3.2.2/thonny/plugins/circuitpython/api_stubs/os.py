def chdir():
    pass


def getcwd():
    pass


def listdir():
    pass


def mkdir():
    pass


def remove():
    pass


def rename():
    pass


def rmdir():
    pass


sep = "/"


def stat():
    pass


def statvfs():
    pass


def sync():
    pass


def uname():
    pass


def unlink():
    pass


def urandom():
    pass
