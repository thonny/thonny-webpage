framebuf = None


def get_lcd():
    pass


lcd160cr = None
math = None


def show_adc():
    pass


def test_all():
    pass


def test_features():
    pass


def test_mandel():
    pass


time = None
