def crc8():
    pass


def readbit():
    pass


def readbyte():
    pass


def reset():
    pass


def writebit():
    pass


def writebyte():
    pass
