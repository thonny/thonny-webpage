_webrepl = None


def accept_conn():
    pass


client_s = None
listen_s = None
network = None


def setup_conn():
    pass


socket = None


def start():
    pass


def start_foreground():
    pass


def stop():
    pass


uos = None
websocket = None
websocket_helper = None
