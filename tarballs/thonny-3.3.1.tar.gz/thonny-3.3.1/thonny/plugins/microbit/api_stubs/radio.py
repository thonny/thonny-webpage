RATE_1MBIT = 0
RATE_250KBIT = 2
RATE_2MBIT = 1


def config():
    pass


def off():
    pass


def on():
    pass


def receive():
    pass


def receive_bytes():
    pass


def receive_bytes_into():
    pass


def receive_full():
    pass


def reset():
    pass


def send():
    pass


def send_bytes():
    pass
