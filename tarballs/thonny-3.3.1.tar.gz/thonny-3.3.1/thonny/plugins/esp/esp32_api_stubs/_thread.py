class LockType:
    ""

    def acquire():
        pass

    def locked():
        pass

    def release():
        pass


def allocate_lock():
    pass


def exit():
    pass


def get_ident():
    pass


def stack_size():
    pass


def start_new_thread():
    pass
