class NotFoundError:
    ""


def _makedirs():
    pass


def cleanup():
    pass


cleanup_files = None
debug = None
errno = None


def expandhome():
    pass


def fatal():
    pass


file_buf = None
gc = None


def get_install_path():
    pass


def get_pkg_metadata():
    pass


gzdict_sz = 31


def help():
    pass


def install():
    pass


install_path = None


def install_pkg():
    pass


def install_tar():
    pass


json = None


def main():
    pass


def op_basename():
    pass


def op_split():
    pass


os = None


def save_file():
    pass


sys = None
tarfile = None


def url_open():
    pass


usocket = None
ussl = None
uzlib = None
warn_ussl = None
