def choice():
    pass


def getrandbits():
    pass


def randint():
    pass


def random():
    pass


def randrange():
    pass


def seed():
    pass


def uniform():
    pass
