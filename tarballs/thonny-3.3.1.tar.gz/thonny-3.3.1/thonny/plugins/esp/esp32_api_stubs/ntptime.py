NTP_DELTA = 3155673600
host = "pool.ntp.org"


def settime():
    pass


socket = None
struct = None


def time():
    pass
