class I2SOut:
    ""

    def deinit():
        pass

    def pause():
        pass

    paused = None

    def play():
        pass

    playing = None

    def resume():
        pass

    def stop():
        pass


class PDMIn:
    ""

    def deinit():
        pass

    def record():
        pass

    sample_rate = None
