class I2C:
    ""

    def deinit():
        pass

    def readfrom_into():
        pass

    def scan():
        pass

    def try_lock():
        pass

    def unlock():
        pass

    def writeto():
        pass


class OneWire:
    ""

    def deinit():
        pass

    def read_bit():
        pass

    def reset():
        pass

    def write_bit():
        pass


class SPI:
    ""

    def configure():
        pass

    def deinit():
        pass

    def readinto():
        pass

    def try_lock():
        pass

    def unlock():
        pass

    def write():
        pass

    def write_readinto():
        pass
