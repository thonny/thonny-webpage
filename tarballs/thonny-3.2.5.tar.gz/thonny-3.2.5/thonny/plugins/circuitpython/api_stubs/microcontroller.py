class Pin:
    ""


class Processor:
    ""
    frequency = None
    temperature = None
    uid = None


class RunMode:
    ""
    BOOTLOADER = None
    NORMAL = None
    SAFE_MODE = None


cpu = None


def delay_us():
    pass


def disable_interrupts():
    pass


def enable_interrupts():
    pass


nvm = None


def on_next_reset():
    pass


pin = None


def reset():
    pass
