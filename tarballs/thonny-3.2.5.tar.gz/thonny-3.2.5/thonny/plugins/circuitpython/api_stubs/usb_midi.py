class PortIn:
    ""

    def read():
        pass

    def readinto():
        pass


class PortOut:
    ""

    def write():
        pass


ports = None
