class Device:
    ""

    def send_report():
        pass

    usage = None
    usage_page = None


devices = None
