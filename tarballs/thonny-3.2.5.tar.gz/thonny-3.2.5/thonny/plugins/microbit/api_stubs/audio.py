class AudioFrame:
    ""

    def copyfrom():
        pass


def is_playing():
    pass


def play():
    pass


def stop():
    pass
