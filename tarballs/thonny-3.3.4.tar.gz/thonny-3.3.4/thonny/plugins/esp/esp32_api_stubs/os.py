class VfsFat:
    ""

    def chdir():
        pass

    def getcwd():
        pass

    def ilistdir():
        pass

    def mkdir():
        pass

    def mkfs():
        pass

    def mount():
        pass

    def open():
        pass

    def remove():
        pass

    def rename():
        pass

    def rmdir():
        pass

    def stat():
        pass

    def statvfs():
        pass

    def umount():
        pass


def chdir():
    pass


def dupterm():
    pass


def dupterm_notify():
    pass


def getcwd():
    pass


def ilistdir():
    pass


def listdir():
    pass


def mkdir():
    pass


def mount():
    pass


def remove():
    pass


def rename():
    pass


def rmdir():
    pass


def stat():
    pass


def statvfs():
    pass


def umount():
    pass


def uname():
    pass


def urandom():
    pass
