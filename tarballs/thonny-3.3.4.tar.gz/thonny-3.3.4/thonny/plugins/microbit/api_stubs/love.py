def badaboom():
    pass
